package com.example.aplicacionnarutofinal.ui

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.aplicacionnarutofinal.data.CharactersNarutoRepository
import com.example.aplicacionnarutofinal.model.CharacterNaruto
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.newSingleThreadContext
import kotlin.coroutines.CoroutineContext

class MainViewModel : ViewModel() {
    private val coroutineContext: CoroutineContext = newSingleThreadContext("NarutoDemo")
    private val scope = CoroutineScope(coroutineContext)
    private val _TAG ="Apidemo"
    //Dependencias

    private val CharacterNarutoRepo = CharactersNarutoRepository()


    //Propiedades
    var characters = MutableLiveData<ArrayList<CharacterNaruto>>()
    var name = "Naruto"


    //Funciones
    fun onStart(){
        scope.launch {
         kotlin.runCatching {
             CharacterNarutoRepo.GetCharactersNaruto(name)
         }.onSuccess {
             Log.d(_TAG, "CharactersNaruto OnSucces")
             characters.postValue(it)
         }.onFailure {
             Log.e(_TAG,"CharactersNaruto ERROR"+ it)
         }
        }

    }

}