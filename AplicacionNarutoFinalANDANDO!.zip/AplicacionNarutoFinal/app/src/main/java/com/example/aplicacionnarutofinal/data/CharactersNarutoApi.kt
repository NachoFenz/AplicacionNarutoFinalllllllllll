package com.example.aplicacionnarutofinal.data

import com.example.aplicacionnarutofinal.model.CharacterNaruto
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface CharactersNarutoApi {
    @GET("/character")
    fun GetCharactersNaruto(
    ): Call<CharacterNaruto>
}