package com.example.aplicacionnarutofinal.data

import android.util.Log
import com.example.aplicacionnarutofinal.model.CharacterNaruto
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class CharactersNarutoDataSource {
    var BASE_URL = "https://api.narutodb.xyz/"
    var _TAG = "Apidemo"


    suspend fun GetCharactersNaruto(name: String): ArrayList<CharacterNaruto> {
        Log.d(_TAG, "CharacterNarutoDataSourceGet")

        val api = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build().create(CharactersNarutoApi::class.java)

        val result = api.GetCharactersNaruto().execute()


        return if (result.isSuccessful) {
            Log.d(_TAG, "Resultado Exitoso")
            val response = result.body()
            response?.let {
                ArrayList<CharacterNaruto>().apply {
                    add(it)
                }
            } ?: ArrayList<CharacterNaruto>()
        } else {
            val errorBody = result.errorBody()?.string()
            val errorMessage = if (errorBody.isNullOrEmpty()) {
                result.message()
            } else {
                errorBody
            }
            Log.e(_TAG, "Error en el llamado api: $errorMessage")
            ArrayList<CharacterNaruto>()
        }
    }
}
