package com.example.aplicacionnarutofinal.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.aplicacionnarutofinal.R
import com.example.aplicacionnarutofinal.model.CharacterNaruto

class CharactersNarutoAdapter : RecyclerView.Adapter<CharacterViewHolder>() {

    private var items: MutableList<CharacterNaruto> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CharacterViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_characternaruto, parent, false)
        return CharacterViewHolder(view)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: CharacterViewHolder, position: Int) {
        holder.bind(items[position])
    }

    fun updateList(list: List<CharacterNaruto>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }
}
