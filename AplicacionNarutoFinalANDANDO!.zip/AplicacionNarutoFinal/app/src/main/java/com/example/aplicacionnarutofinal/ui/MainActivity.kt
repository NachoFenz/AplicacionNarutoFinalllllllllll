package com.example.aplicacionnarutofinal.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.aplicacionnarutofinal.R

class MainActivity : AppCompatActivity() {

    private lateinit var viewModel: MainViewModel
    private lateinit var rvCharactersNaruto: RecyclerView
    private lateinit var adapter: CharactersNarutoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        bindViewModel()
    }

    override fun onStart() {
        super.onStart()
        viewModel.onStart()
    }

    private fun bindViews() {
        rvCharactersNaruto = findViewById(R.id.rvCharactersNaruto)
        rvCharactersNaruto.layoutManager = LinearLayoutManager(this)
        adapter = CharactersNarutoAdapter()
        rvCharactersNaruto.adapter = adapter
    }

    private fun bindViewModel() {
        viewModel = ViewModelProvider(this)[MainViewModel::class.java]
        viewModel.characters.observe(this) { characters ->
            adapter.updateList(characters)
        }
    }
}