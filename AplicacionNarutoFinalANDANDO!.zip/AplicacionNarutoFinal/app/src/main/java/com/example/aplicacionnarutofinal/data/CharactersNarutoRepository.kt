package com.example.aplicacionnarutofinal.data

import com.example.aplicacionnarutofinal.model.CharacterNaruto

class CharactersNarutoRepository {
  //Dependencias

    private val CharactersNarutoDs = CharactersNarutoDataSource()
    suspend fun  GetCharactersNaruto (name:String)  :  ArrayList<CharacterNaruto> {
    return CharactersNarutoDs.GetCharactersNaruto(name)
    }
}