package com.example.aplicacionnarutofinal.model

data class CharacterNaruto(
val id: String,
val name: String,
val images: String,
val debut: Debut,
val personal: Personal,
val family: Family,
val jutsu: List<String>,
val natureType: List<String>,
val uniqueTraits: List<String>,
val voiceActors: List<VoiceActor>
)

data class Debut(
    val novel: String?,
    val movie: String?,
    val appearsIn: String?
)

data class Personal(
    val species: String?,
    // Otros detalles personales del personaje
)

data class Family(
    val incarnationWithGodTree: String?,
    val depoweredForm: String?
)

data class VoiceActor(
    val language: String,
    val actor: String
)